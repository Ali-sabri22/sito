import emailjs from '@emailjs/browser';

// EmailJS configuration
const EMAILJS_SERVICE_ID = 'service_cprchen';
const EMAILJS_ORDER_TEMPLATE_ID = 'template_rgeruiw';
const EMAILJS_CONTACT_TEMPLATE_ID = 'template_j82t2eu';
const EMAILJS_PUBLIC_KEY = 'l02ZfNM2YR-AL81XK';

// Initialize EmailJS
emailjs.init(EMAILJS_PUBLIC_KEY);

export interface OrderEmailData {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  orderItems: Array<{
    name: string;
    quantity: number;
    price: number;
    total: number;
    variant?: string;
  }>;
  subtotal: number;
  shippingCost: number;
  totalAmount: number;
  paymentMethod: string;
  orderDate: string;
  orderId: string;
}

export const sendOrderConfirmationEmail = async (orderData: OrderEmailData): Promise<boolean> => {
  try {
    // Format order items with better structure
    const formattedItems = orderData.orderItems.map((item) => {
      const productName = item.variant ? `${item.name} (${item.variant})` : item.name;
      return `اسم المنتج: ${productName}
الكمية: ${item.quantity}
السعر: ${item.price} جنيه
المجموع: ${item.total} جنيه`;
    }).join('\n\n');

    // Prepare template parameters
    const templateParams = {
      customer_name: orderData.customerName,
      customer_email: orderData.customerEmail,
      customer_phone: orderData.customerPhone,
      customer_address: orderData.customerAddress,
      order_id: orderData.orderId,
      order_date: orderData.orderDate,
      order_items: formattedItems,
      subtotal: orderData.subtotal.toFixed(2),
      shipping_cost: orderData.shippingCost.toFixed(2),
      total_amount: orderData.totalAmount.toFixed(2),
      payment_method: orderData.paymentMethod,
      items_count: orderData.orderItems.length,
      to_email: orderData.customerEmail,
      to_name: orderData.customerName,
    };

    console.log('Sending email with data:', templateParams);

    // Send email using EmailJS
    const response = await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_ORDER_TEMPLATE_ID,
      templateParams
    );

    console.log('Email sent successfully:', response);
    return true;
  } catch (error) {
    console.error('Failed to send email:', error);
    return false;
  }
};

// Function to send contact form email
export const sendContactEmail = async (contactData: {
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
}): Promise<boolean> => {
  try {
    const response = await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_CONTACT_TEMPLATE_ID,
      {
        from_name: contactData.name,
        from_email: contactData.email,
        phone: contactData.phone || 'غير محدد',
        subject: contactData.subject,
        message: contactData.message,
        to_email: 'info@sabil.eg'
      }
    );

    console.log('Contact email sent successfully:', response);
    return true;
  } catch (error) {
    console.error('Failed to send contact email:', error);
    return false;
  }
};

// Function to generate order ID
export const generateOrderId = (): string => {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 1000);
  return `ORD-${timestamp}-${random}`;
};

// Function to format date in Arabic
export const formatOrderDate = (): string => {
  const now = new Date();
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Africa/Cairo'
  };
  
  return now.toLocaleDateString('ar-EG', options);
};

// Function to get payment method name in Arabic
export const getPaymentMethodName = (method: string): string => {
  const paymentMethods: Record<string, string> = {
    'cod': 'الدفع عند الاستلام',
    'fawry': 'فوري',
    'vodafone': 'فودافون كاش',
    'card': 'بطاقة ائتمانية'
  };
  
  return paymentMethods[method] || method;
};