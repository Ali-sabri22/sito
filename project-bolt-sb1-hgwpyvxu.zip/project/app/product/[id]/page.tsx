'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useParams } from 'next/navigation';
import { 
  Star, 
  Heart, 
  Share2, 
  Minus, 
  Plus, 
  ShoppingCart, 
  Shield, 
  Truck, 
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Check,
  X,
  ShoppingBag
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/contexts/CartContext';
import Link from 'next/link';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  images: string[];
  rating: number;
  reviews: number;
  category: string;
  badge?: string;
  inStock: boolean;
  description: string;
  features: string[];
  specifications: Record<string, string>;
  variants?: { name: string; options: string[] }[];
}

export default function ProductPage() {
  const params = useParams();
  const productId = params.id as string;
  const { addItem } = useCart();

  const [product] = useState<Product>({
    id: productId,
    name: `المنتج ${getProductNameByNumber(productId)}`,
    price: 2500,
    originalPrice: 3000,
    images: ['/image.png', '/image.png', '/image.png'],
    rating: 4.8,
    reviews: 124,
    category: 'shorts',
    badge: 'خصم 20%',
    inStock: true,
    description: 'شورت سبيل عالي الجودة مصمم خصيصاً للرجال المسلمين. يغطي من السرة للركبة ويوفر راحة تامة في البحر والجيم والحياة اليومية. مصنوع من أفضل الخامات مع تصميم أنيق ومريح.',
    features: [
      'تغطية من السرة للركبة حسب الشريعة الإسلامية',
      'قماش عالي الجودة مقاوم للماء',
      'تصميم مريح ومرن للحركة',
      'خياطة متينة تدوم طويلاً',
      'ألوان ثابتة لا تبهت',
      'سهولة في الحركة والرياضة',
      'مناسب للبحر والجيم والحياة اليومية',
      'تصميم عصري وأنيق'
    ],
    specifications: {
      'المادة': '100% بوليستر عالي الجودة',
      'الطول': 'من السرة للركبة (حوالي 45 سم)',
      'المقاسات المتاحة': 'S, M, L, XL, XXL',
      'الألوان المتاحة': 'أسود، كحلي، رمادي، بني',
      'طريقة العناية': 'غسيل عادي في الغسالة 30 درجة',
      'المنشأ': 'مصر - ميت دمسيس، المنصورة',
      'الضمان': 'ضمان الجودة لمدة سنة كاملة',
      'الوزن': '200 جرام تقريباً'
    },
    variants: [
      {
        name: 'اللون',
        options: ['أسود', 'كحلي', 'رمادي', 'بني']
      },
      {
        name: 'المقاس',
        options: ['صغير (S)', 'متوسط (M)', 'كبير (L)', 'كبير جداً (XL)', 'كبير جداً جداً (XXL)']
      }
    ]
  });

  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const relatedProducts = [
    {
      id: '2',
      name: 'المنتج الثاني',
      price: 850,
      image: '/image.png',
      rating: 4.6
    },
    {
      id: '3',
      name: 'المنتج الثالث',
      price: 1200,
      image: '/image.png',
      rating: 4.9
    },
    {
      id: '4',
      name: 'المنتج الرابع',
      price: 450,
      image: '/image.png',
      rating: 4.7
    }
  ];

  function getProductNameByNumber(id: string): string {
    const numbers = ['', 'الاول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن'];
    const num = parseInt(id);
    return numbers[num] || `رقم ${id}`;
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  const handleAddToCart = async () => {
    setIsLoading(true);
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      variant: Object.entries(selectedVariants).map(([key, value]) => `${key}: ${value}`).join(', ')
    });
    
    setIsLoading(false);
  };

  const handleBuyNow = async () => {
    await handleAddToCart();
    // Redirect to checkout
    window.location.href = '/checkout';
  };

  const handleVariantChange = (variantName: string, option: string) => {
    setSelectedVariants(prev => ({
      ...prev,
      [variantName]: option
    }));
  };

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600 mb-8">
          <Link href="/" className="hover:text-orange-600">الرئيسية</Link>
          <ChevronLeft className="w-4 h-4" />
          <Link href="/shop" className="hover:text-orange-600">المتجر</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-900">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            {/* Main Image */}
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-gray-100">
              <img
                src={product.images[currentImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              
              {/* Navigation Arrows */}
              <Button
                variant="outline"
                size="sm"
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur-sm"
                onClick={prevImage}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur-sm"
                onClick={nextImage}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>

              {/* Image Indicators */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2 space-x-reverse">
                {product.images.map((_, index) => (
                  <button
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentImageIndex ? 'bg-white w-6' : 'bg-white/50'
                    }`}
                    onClick={() => setCurrentImageIndex(index)}
                  />
                ))}
              </div>
            </div>

            {/* Thumbnail Images */}
            <div className="flex space-x-4 space-x-reverse">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                    index === currentImageIndex ? 'border-orange-500' : 'border-gray-200'
                  }`}
                  onClick={() => setCurrentImageIndex(index)}
                >
                  <img
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Badge and Category */}
            <div className="flex items-center space-x-3 space-x-reverse">
              {product.badge && (
                <Badge className="bg-orange-500">{product.badge}</Badge>
              )}
              <Badge variant="outline">شورتات سبيل</Badge>
            </div>

            {/* Title */}
            <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="flex items-center space-x-1 space-x-reverse">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating)
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
                <span className="text-lg font-medium">{product.rating}</span>
              </div>
              <span className="text-gray-600">({product.reviews} تقييم)</span>
            </div>

            {/* Price */}
            <div className="space-y-2">
              <div className="flex items-center space-x-4 space-x-reverse">
                <span className="text-4xl font-bold text-orange-600">
                  {product.price} جنيه
                </span>
                {product.originalPrice && (
                  <span className="text-2xl text-gray-500 line-through">
                    {product.originalPrice} جنيه
                  </span>
                )}
              </div>
              {product.originalPrice && (
                <p className="text-green-600 font-medium">
                  توفر {product.originalPrice - product.price} جنيه 
                  ({Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%)
                </p>
              )}
            </div>

            {/* Stock Status */}
            <div className="flex items-center space-x-2 space-x-reverse">
              {product.inStock ? (
                <>
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-green-600 font-medium">متوفر في المخزون</span>
                </>
              ) : (
                <>
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-red-600 font-medium">غير متوفر</span>
                </>
              )}
            </div>

            {/* Variants */}
            {product.variants?.map((variant) => (
              <div key={variant.name} className="space-y-3">
                <h3 className="font-semibold">{variant.name}:</h3>
                <div className="flex flex-wrap gap-2">
                  {variant.options.map((option) => (
                    <button
                      key={option}
                      className={`px-4 py-2 border rounded-lg transition-all ${
                        selectedVariants[variant.name] === option
                          ? 'border-orange-500 bg-orange-50 text-orange-600'
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                      onClick={() => handleVariantChange(variant.name, option)}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            {/* Quantity */}
            <div className="space-y-3">
              <h3 className="font-semibold">الكمية:</h3>
              <div className="flex items-center space-x-4 space-x-reverse">
                <div className="flex items-center border rounded-lg">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="px-4 py-2 font-medium">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <span className="text-gray-600">
                  المجموع: <span className="font-bold text-orange-600">
                    {(product.price * quantity).toLocaleString()} جنيه
                  </span>
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                size="lg"
                className="w-full bg-orange-500 hover:bg-orange-600"
                onClick={handleBuyNow}
                disabled={!product.inStock || isLoading}
              >
                {isLoading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                  />
                ) : (
                  <>
                    <ShoppingBag className="w-5 h-5 ml-2" />
                    اشتري الآن
                  </>
                )}
              </Button>

              <Button
                variant="outline"
                size="lg"
                className="w-full"
                onClick={handleAddToCart}
                disabled={!product.inStock || isLoading}
              >
                <ShoppingCart className="w-5 h-5 ml-2" />
                أضف إلى السلة
              </Button>

              <div className="flex space-x-2 space-x-reverse">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setIsWishlisted(!isWishlisted)}
                  className={`flex-1 ${isWishlisted ? 'text-red-500 border-red-500' : ''}`}
                >
                  <Heart className={`w-5 h-5 ml-2 ${isWishlisted ? 'fill-current' : ''}`} />
                  {isWishlisted ? 'في المفضلة' : 'أضف للمفضلة'}
                </Button>

                <Button variant="outline" size="lg">
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t">
              <div className="flex items-center space-x-3 space-x-reverse">
                <Shield className="w-6 h-6 text-orange-500" />
                <div>
                  <p className="font-medium">ضمان سنة</p>
                  <p className="text-sm text-gray-600">ضمان شامل</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Truck className="w-6 h-6 text-orange-500" />
                <div>
                  <p className="font-medium">شحن مجاني</p>
                  <p className="text-sm text-gray-600">خلال 2-3 أيام</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <RefreshCw className="w-6 h-6 text-orange-500" />
                <div>
                  <p className="font-medium">إرجاع مجاني</p>
                  <p className="text-sm text-gray-600">خلال 30 يوم</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Product Details Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-16"
        >
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">الوصف</TabsTrigger>
              <TabsTrigger value="specifications">المواصفات</TabsTrigger>
              <TabsTrigger value="reviews">التقييمات</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <p className="text-lg leading-relaxed mb-6">{product.description}</p>
                  <h3 className="font-semibold text-xl mb-4">المزايا الرئيسية:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {product.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3 space-x-reverse">
                        <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="specifications" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between items-center py-3 border-b border-gray-100 last:border-b-0">
                        <span className="font-medium text-gray-900">{key}</span>
                        <span className="text-gray-600">{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <div className="space-y-6">
                    {/* Reviews Summary */}
                    <div className="flex items-center justify-between pb-6 border-b">
                      <div>
                        <h3 className="text-2xl font-bold mb-2">تقييمات العملاء</h3>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-5 h-5 ${
                                  i < Math.floor(product.rating)
                                    ? 'text-yellow-400 fill-current'
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-lg font-medium">{product.rating} من 5</span>
                          <span className="text-gray-600">({product.reviews} تقييم)</span>
                        </div>
                      </div>
                      <Button variant="outline">اكتب تقييم</Button>
                    </div>

                    {/* Sample Reviews */}
                    {[
                      {
                        name: 'أحمد محمد',
                        rating: 5,
                        date: '2024-01-15',
                        comment: 'منتج ممتاز جداً، الجودة عالية والتصميم مريح. يغطي بالفعل من السرة للركبة كما هو مطلوب شرعياً. أنصح به بشدة.'
                      },
                      {
                        name: 'محمد علي',
                        rating: 4,
                        date: '2024-01-10',
                        comment: 'جودة ممتازة وخامة رائعة. مريح جداً في الجيم والبحر. التوصيل كان سريع والخدمة ممتازة.'
                      }
                    ].map((review, index) => (
                      <div key={index} className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3 space-x-reverse">
                            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                              <span className="font-medium text-orange-600">
                                {review.name.charAt(0)}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium">{review.name}</p>
                              <div className="flex items-center space-x-1 space-x-reverse">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-4 h-4 ${
                                      i < review.rating
                                        ? 'text-yellow-400 fill-current'
                                        : 'text-gray-300'
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>
                          <span className="text-sm text-gray-500">{review.date}</span>
                        </div>
                        <p className="text-gray-700 mr-13">{review.comment}</p>
                        <Separator />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Related Products */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-3xl font-bold mb-8">منتجات ذات صلة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedProducts.map((relatedProduct, index) => (
              <motion.div
                key={relatedProduct.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
              >
                <Card className="group hover:shadow-lg transition-all duration-300">
                  <div className="relative">
                    <img
                      src={relatedProduct.image}
                      alt={relatedProduct.name}
                      className="w-full h-48 object-cover rounded-t-lg group-hover:scale-105 transition-transform duration-300"
                    />
                    <Button
                      size="sm"
                      className="absolute bottom-3 left-1/2 transform -translate-x-1/2 bg-orange-500 hover:bg-orange-600 opacity-0 group-hover:opacity-100 transition-all duration-300"
                    >
                      <ShoppingCart className="w-4 h-4 ml-2" />
                      أضف للسلة
                    </Button>
                  </div>
                  <CardContent className="p-4">
                    <Link href={`/product/${relatedProduct.id}`}>
                      <h3 className="font-semibold mb-2 group-hover:text-orange-600 transition-colors">
                        {relatedProduct.name}
                      </h3>
                    </Link>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-orange-600">
                        {relatedProduct.price} جنيه
                      </span>
                      <div className="flex items-center space-x-1 space-x-reverse">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm">{relatedProduct.rating}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>
      </div>
    </div>
  );
}