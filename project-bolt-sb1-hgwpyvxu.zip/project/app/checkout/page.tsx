'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  CreditCard, 
  MapPin, 
  Package, 
  Shield,
  Truck,
  User,
  Mail,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { 
  sendOrderConfirmationEmail, 
  generateOrderId, 
  formatOrderDate, 
  getPaymentMethodName,
  type OrderEmailData 
} from '@/lib/emailjs';
import { toast } from 'sonner';
import Link from 'next/link';

export default function CheckoutPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Shipping info
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    governorate: '',
    postalCode: '',
    // Payment info
    paymentMethod: 'cod',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const { state: cartState, clearCart } = useCart();
  const { user } = useAuth();

  const steps = [
    { id: 1, title: 'معلومات الشحن', icon: Truck },
    { id: 2, title: 'طريقة الدفع', icon: CreditCard },
    { id: 3, title: 'مراجعة الطلب', icon: Package },
  ];

  const paymentMethods = [
    { id: 'cod', name: 'الدفع عند الاستلام', icon: Package, description: 'ادفع نقداً عند وصول الطلب' },
    { id: 'fawry', name: 'فوري', icon: CreditCard, description: 'ادفع عبر فوري' },
    { id: 'vodafone', name: 'فودافون كاش', icon: CreditCard, description: 'ادفع عبر فودافون كاش' },
    { id: 'card', name: 'بطاقة ائتمانية', icon: CreditCard, description: 'فيزا أو ماستركارد' },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    if (step === 1) {
      if (!formData.firstName.trim()) newErrors.firstName = 'الاسم الأول مطلوب';
      if (!formData.lastName.trim()) newErrors.lastName = 'الاسم الأخير مطلوب';
      if (!formData.email.trim()) newErrors.email = 'البريد الإلكتروني مطلوب';
      if (!formData.phone.trim()) newErrors.phone = 'رقم الهاتف مطلوب';
      if (!formData.address.trim()) newErrors.address = 'العنوان مطلوب';
      if (!formData.city.trim()) newErrors.city = 'المدينة مطلوبة';
      if (!formData.governorate.trim()) newErrors.governorate = 'المحافظة مطلوبة';
    }

    if (step === 2 && formData.paymentMethod === 'card') {
      if (!formData.cardName.trim()) newErrors.cardName = 'اسم حامل البطاقة مطلوب';
      if (!formData.cardNumber.trim()) newErrors.cardNumber = 'رقم البطاقة مطلوب';
      if (!formData.expiryDate.trim()) newErrors.expiryDate = 'تاريخ الانتهاء مطلوب';
      if (!formData.cvv.trim()) newErrors.cvv = 'CVV مطلوب';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (validateStep(currentStep)) {
      if (currentStep < 3) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmitOrder = async () => {
    if (!validateStep(currentStep)) {
      return;
    }

    if (cartState.items.length === 0) {
      toast.error('السلة فارغة');
      return;
    }

    setIsLoading(true);

    try {
      // Generate order details
      const newOrderId = generateOrderId();
      const orderDate = formatOrderDate();
      const shippingCost = cartState.total > 500 ? 0 : 50;
      const totalWithShipping = cartState.total + shippingCost;

      // Prepare order data for email
      const orderData: OrderEmailData = {
        customerName: `${formData.firstName} ${formData.lastName}`,
        customerEmail: formData.email,
        customerPhone: formData.phone,
        customerAddress: `${formData.address}, ${formData.city}, ${formData.governorate}${formData.postalCode ? `, ${formData.postalCode}` : ''}`,
        orderItems: cartState.items.map(item => ({
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          total: item.price * item.quantity,
          variant: item.variant
        })),
        subtotal: cartState.total,
        shippingCost: shippingCost,
        totalAmount: totalWithShipping,
        paymentMethod: getPaymentMethodName(formData.paymentMethod),
        orderDate: orderDate,
        orderId: newOrderId
      };

      // Send email
      const emailSent = await sendOrderConfirmationEmail(orderData);

      if (emailSent) {
        // Simulate order processing
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setOrderId(newOrderId);
        setOrderSuccess(true);
        clearCart();
        
        toast.success('تم إرسال الطلب بنجاح! ستصلك رسالة تأكيد على البريد الإلكتروني.');
      } else {
        toast.error('حدث خطأ في إرسال البريد الإلكتروني. يرجى المحاولة مرة أخرى.');
      }
    } catch (error) {
      console.error('Order submission error:', error);
      toast.error('حدث خطأ في معالجة الطلب. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsLoading(false);
    }
  };

  const shippingCost = cartState.total > 500 ? 0 : 50;
  const totalWithShipping = cartState.total + shippingCost;

  // Order Success Screen
  if (orderSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full mx-4"
        >
          <Card className="text-center">
            <CardContent className="p-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
              >
                <CheckCircle className="w-10 h-10 text-green-600" />
              </motion.div>
              
              <h1 className="text-2xl font-bold text-gray-900 mb-4">
                تم تأكيد طلبك بنجاح!
              </h1>
              
              <p className="text-gray-600 mb-6">
                رقم الطلب: <span className="font-semibold text-orange-600">{orderId}</span>
              </p>
              
              <p className="text-gray-600 mb-8">
                تم إرسال تفاصيل الطلب إلى بريدك الإلكتروني. سنتواصل معك قريباً لتأكيد التوصيل.
              </p>
              
              <div className="space-y-3">
                <Button asChild className="w-full">
                  <Link href="/shop">متابعة التسوق</Link>
                </Button>
                <Button variant="outline" asChild className="w-full">
                  <Link href="/">العودة للرئيسية</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600 mb-8">
          <Link href="/" className="hover:text-orange-600">الرئيسية</Link>
          <ArrowLeft className="w-4 h-4" />
          <Link href="/cart" className="hover:text-orange-600">السلة</Link>
          <ArrowLeft className="w-4 h-4" />
          <span className="text-gray-900">إتمام الطلب</span>
        </nav>

        {/* Steps Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-8 space-x-reverse">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex items-center">
                  <div className={`flex items-center space-x-3 space-x-reverse ${
                    isActive ? 'text-orange-600' : isCompleted ? 'text-green-600' : 'text-gray-400'
                  }`}>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                      isActive ? 'border-orange-600 bg-orange-50' : 
                      isCompleted ? 'border-green-600 bg-green-50' : 
                      'border-gray-300 bg-white'
                    }`}>
                      {isCompleted ? (
                        <Check className="w-5 h-5" />
                      ) : (
                        <Icon className="w-5 h-5" />
                      )}
                    </div>
                    <span className="font-medium">{step.title}</span>
                  </div>
                  
                  {index < steps.length - 1 && (
                    <div className={`w-16 h-0.5 mx-4 ${
                      currentStep > step.id ? 'bg-green-600' : 'bg-gray-300'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Step 1: Shipping Information */}
              {currentStep === 1 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 space-x-reverse">
                      <Truck className="w-5 h-5" />
                      <span>معلومات الشحن</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">الاسم الأول *</Label>
                        <Input
                          id="firstName"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          placeholder="أدخل الاسم الأول"
                          className={errors.firstName ? 'border-red-500' : ''}
                        />
                        {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
                      </div>
                      <div>
                        <Label htmlFor="lastName">الاسم الأخير *</Label>
                        <Input
                          id="lastName"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          placeholder="أدخل الاسم الأخير"
                          className={errors.lastName ? 'border-red-500' : ''}
                        />
                        {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="email">البريد الإلكتروني *</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="أدخل بريدك الإلكتروني"
                          className={errors.email ? 'border-red-500' : ''}
                        />
                        {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                      </div>
                      <div>
                        <Label htmlFor="phone">رقم الهاتف *</Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="أدخل رقم الهاتف"
                          className={errors.phone ? 'border-red-500' : ''}
                        />
                        {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="address">العنوان *</Label>
                      <Input
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="أدخل العنوان بالتفصيل"
                        className={errors.address ? 'border-red-500' : ''}
                      />
                      {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address}</p>}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="city">المدينة *</Label>
                        <Input
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="المدينة"
                          className={errors.city ? 'border-red-500' : ''}
                        />
                        {errors.city && <p className="text-red-500 text-sm mt-1">{errors.city}</p>}
                      </div>
                      <div>
                        <Label htmlFor="governorate">المحافظة *</Label>
                        <Input
                          id="governorate"
                          name="governorate"
                          value={formData.governorate}
                          onChange={handleInputChange}
                          placeholder="المحافظة"
                          className={errors.governorate ? 'border-red-500' : ''}
                        />
                        {errors.governorate && <p className="text-red-500 text-sm mt-1">{errors.governorate}</p>}
                      </div>
                      <div>
                        <Label htmlFor="postalCode">الرمز البريدي</Label>
                        <Input
                          id="postalCode"
                          name="postalCode"
                          value={formData.postalCode}
                          onChange={handleInputChange}
                          placeholder="الرمز البريدي"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Step 2: Payment Method */}
              {currentStep === 2 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 space-x-reverse">
                      <CreditCard className="w-5 h-5" />
                      <span>طريقة الدفع</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <RadioGroup
                      value={formData.paymentMethod}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value }))}
                    >
                      {paymentMethods.map((method) => {
                        const Icon = method.icon;
                        return (
                          <div key={method.id} className="flex items-center space-x-3 space-x-reverse p-4 border rounded-lg hover:bg-gray-50">
                            <RadioGroupItem value={method.id} id={method.id} />
                            <Icon className="w-5 h-5 text-gray-600" />
                            <div className="flex-1">
                              <Label htmlFor={method.id} className="font-medium cursor-pointer">
                                {method.name}
                              </Label>
                              <p className="text-sm text-gray-500">{method.description}</p>
                            </div>
                          </div>
                        );
                      })}
                    </RadioGroup>

                    {/* Credit Card Form */}
                    {formData.paymentMethod === 'card' && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="space-y-4 p-4 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <Label htmlFor="cardName">اسم حامل البطاقة *</Label>
                          <Input
                            id="cardName"
                            name="cardName"
                            value={formData.cardName}
                            onChange={handleInputChange}
                            placeholder="الاسم كما هو مكتوب على البطاقة"
                            className={errors.cardName ? 'border-red-500' : ''}
                          />
                          {errors.cardName && <p className="text-red-500 text-sm mt-1">{errors.cardName}</p>}
                        </div>
                        <div>
                          <Label htmlFor="cardNumber">رقم البطاقة *</Label>
                          <Input
                            id="cardNumber"
                            name="cardNumber"
                            value={formData.cardNumber}
                            onChange={handleInputChange}
                            placeholder="1234 5678 9012 3456"
                            className={errors.cardNumber ? 'border-red-500' : ''}
                          />
                          {errors.cardNumber && <p className="text-red-500 text-sm mt-1">{errors.cardNumber}</p>}
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiryDate">تاريخ الانتهاء *</Label>
                            <Input
                              id="expiryDate"
                              name="expiryDate"
                              value={formData.expiryDate}
                              onChange={handleInputChange}
                              placeholder="MM/YY"
                              className={errors.expiryDate ? 'border-red-500' : ''}
                            />
                            {errors.expiryDate && <p className="text-red-500 text-sm mt-1">{errors.expiryDate}</p>}
                          </div>
                          <div>
                            <Label htmlFor="cvv">CVV *</Label>
                            <Input
                              id="cvv"
                              name="cvv"
                              value={formData.cvv}
                              onChange={handleInputChange}
                              placeholder="123"
                              className={errors.cvv ? 'border-red-500' : ''}
                            />
                            {errors.cvv && <p className="text-red-500 text-sm mt-1">{errors.cvv}</p>}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Step 3: Order Review */}
              {currentStep === 3 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 space-x-reverse">
                      <Package className="w-5 h-5" />
                      <span>مراجعة الطلب</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Order Items */}
                    <div className="space-y-4">
                      {cartState.items.map((item) => (
                        <div key={item.id} className="flex items-center space-x-4 space-x-reverse p-4 bg-gray-50 rounded-lg">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-16 h-16 object-cover rounded"
                          />
                          <div className="flex-1">
                            <h4 className="font-medium">{item.name}</h4>
                            {item.variant && (
                              <p className="text-sm text-gray-500">{item.variant}</p>
                            )}
                            <p className="text-sm text-gray-600">الكمية: {item.quantity}</p>
                          </div>
                          <div className="text-lg font-semibold text-orange-600">
                            {(item.price * item.quantity).toFixed(2)} جنيه
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Shipping & Payment Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <h4 className="font-semibold flex items-center space-x-2 space-x-reverse">
                          <MapPin className="w-4 h-4" />
                          <span>عنوان الشحن</span>
                        </h4>
                        <div className="text-sm text-gray-600">
                          <p>{formData.firstName} {formData.lastName}</p>
                          <p>{formData.address}</p>
                          <p>{formData.city}, {formData.governorate}</p>
                          <p>{formData.phone}</p>
                          <p>{formData.email}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <h4 className="font-semibold flex items-center space-x-2 space-x-reverse">
                          <CreditCard className="w-4 h-4" />
                          <span>طريقة الدفع</span>
                        </h4>
                        <div className="text-sm text-gray-600">
                          <p>{paymentMethods.find(m => m.id === formData.paymentMethod)?.name}</p>
                        </div>
                      </div>
                    </div>

                    {/* Terms */}
                    <div className="flex items-start space-x-2 space-x-reverse">
                      <Checkbox id="terms" />
                      <Label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
                        أوافق على 
                        <Link href="/terms" className="text-orange-600 hover:text-orange-700"> شروط الاستخدام </Link>
                        و
                        <Link href="/privacy" className="text-orange-600 hover:text-orange-700"> سياسة الخصوصية</Link>
                      </Label>
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={handlePrevStep}
                disabled={currentStep === 1}
                className="flex items-center space-x-2 space-x-reverse"
              >
                <ArrowRight className="w-4 h-4" />
                <span>السابق</span>
              </Button>

              {currentStep < 3 ? (
                <Button
                  onClick={handleNextStep}
                  className="flex items-center space-x-2 space-x-reverse bg-orange-500 hover:bg-orange-600"
                >
                  <span>التالي</span>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmitOrder}
                  disabled={isLoading}
                  className="flex items-center space-x-2 space-x-reverse bg-green-600 hover:bg-green-700"
                >
                  {isLoading ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                    />
                  ) : (
                    <>
                      <span>تأكيد الطلب</span>
                      <Mail className="w-4 h-4" />
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>ملخص الطلب</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>المجموع الفرعي</span>
                    <span>{cartState.total.toFixed(2)} جنيه</span>
                  </div>
                  <div className="flex justify-between">
                    <span>الشحن</span>
                    <span className={shippingCost === 0 ? 'text-green-600' : ''}>
                      {shippingCost === 0 ? 'مجاني' : `${shippingCost} جنيه`}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-semibold">
                    <span>المجموع الكلي</span>
                    <span className="text-orange-600">{totalWithShipping.toFixed(2)} جنيه</span>
                  </div>
                </div>

                {/* Security Features */}
                <div className="space-y-3 pt-4 border-t">
                  <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span>دفع آمن ومحمي</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                    <Truck className="w-4 h-4 text-blue-500" />
                    <span>شحن سريع وموثوق</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                    <Package className="w-4 h-4 text-orange-500" />
                    <span>ضمان الجودة</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                    <Mail className="w-4 h-4 text-purple-500" />
                    <span>تأكيد عبر البريد الإلكتروني</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}