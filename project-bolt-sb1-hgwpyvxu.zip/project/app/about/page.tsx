'use client';

import { motion } from 'framer-motion';
import { Users, Target, Award, Heart } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: 'الاحتشام والراحة',
      description: 'نؤمن بأن الاحتشام لا يعني التنازل عن الراحة أو الأناقة'
    },
    {
      icon: Award,
      title: 'الجودة العالية',
      description: 'نختار أفضل الخامات ونعمل مع أمهر الحرفيين لضمان أعلى جودة'
    },
    {
      icon: Target,
      title: 'الهدف الواضح',
      description: 'هدفنا واضح: توفير لبس محتشم ومريح لكل شاب مسلم'
    },
    {
      icon: Users,
      title: 'المجتمع',
      description: 'نبني مجتمعاً من الشباب الواعي الذي يحترم قيمه ودينه'
    }
  ];

  const timeline = [
    {
      year: '2025',
      title: 'البداية',
      description: 'تأسيس سبيل في ميت دمسيس، المنصورة على يد 4 شباب'
    },
    {
      year: '2025',
      title: 'أول منتج',
      description: 'إطلاق أول مجموعة من شورتات سبيل'
    },
    {
      year: '2025',
      title: 'التوسع',
      description: 'خطط للتوسع وإضافة منتجات جديدة'
    }
  ];

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-6 text-gray-900">من نحن</h1>
          <div className="max-w-4xl mx-auto">
            <div className="text-xl leading-relaxed text-gray-700 space-y-6">
              <p>
                <strong className="text-orange-600">سبيل</strong> هو براند مصري اتأسس سنة 2025 في مدينة ميت دمسيس، بمحافظة المنصورة، على إيد 4 شباب أعمارهم بين 17 و18 سنة.
              </p>
              
              <p>
                فكرة البراند جات من دافع ديني، علشان الرجالة المسلمين لازم يغطّوا جسمهم من السُرّة للركبة في الأماكن العامة زي البحر، الجيم، أو في أي رياضة. للأسف معظم اللبس اللي في السوق مش بيحقق الشرط ده، عشان كده قررنا نبدأ حاجة مختلفة.
              </p>
              
              <p>
                اخترنا اسم <strong className="text-orange-600">"سبيل"</strong> لأنه بيعبر عن الطريق اللي ماشيين فيه، طريق الاحتشام والاحترام والراحة في نفس الوقت.
              </p>
              
              <p>
                إحنا بنختار القماش بعناية، وبنوديه لمصنع خاص بينفذ التصميمات بتاعتنا بجودة عالية. اللي بيميز شورتات سبيل هو القَصّة المدروسة اللي بتغطي المنطقة المطلوبة بالظبط، ومع خامة بتتنفس وتصميم بسيط وأنيق.
              </p>
              
              <p className="text-2xl font-semibold text-orange-600">
                هدفنا إن أي شاب مسلم يلاقي لبس مريح، محتشم، وفي نفس الوقت عصري، سواء في البحر، أو الجيم، أو حياته اليومية.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Values Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-4xl font-bold text-center mb-12">قيمنا ومبادئنا</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                    <CardContent className="p-6 text-center">
                      <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Icon className="w-8 h-8 text-orange-600" />
                      </div>
                      <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                      <p className="text-gray-600 leading-relaxed">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.section>

        {/* Timeline Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-4xl font-bold text-center mb-12">رحلتنا</h2>
          <div className="max-w-3xl mx-auto">
            {timeline.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="flex items-start mb-8 last:mb-0"
              >
                <div className="flex-shrink-0 w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {item.year}
                </div>
                <div className="mr-6">
                  <h3 className="text-2xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-lg leading-relaxed">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Mission Statement */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-12 text-center"
        >
          <h2 className="text-4xl font-bold mb-6 text-gray-900">رسالتنا</h2>
          <p className="text-2xl leading-relaxed text-gray-700 max-w-4xl mx-auto">
            نسعى لأن نكون الخيار الأول لكل شاب مسلم يبحث عن لبس يجمع بين الاحتشام والراحة والأناقة. 
            نريد أن نساهم في بناء مجتمع واعي يحترم قيمه الدينية دون التنازل عن الحداثة والجودة.
          </p>
        </motion.section>

        {/* Team Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mt-16"
        >
          <h2 className="text-4xl font-bold text-center mb-12">فريق العمل</h2>
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-32 h-32 bg-orange-100 rounded-full mb-6">
              <Users className="w-16 h-16 text-orange-600" />
            </div>
            <h3 className="text-2xl font-semibold mb-4">4 شباب مؤسسين</h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              فريق شاب ومتحمس من ميت دمسيس، المنصورة، أعمارهم بين 17 و18 سنة، 
              يحملون رؤية واضحة لتغيير صناعة الملابس الرياضية في العالم العربي
            </p>
          </div>
        </motion.section>
      </div>
    </div>
  );
}