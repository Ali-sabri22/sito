'use client';

import { motion } from 'framer-motion';
import { HeroSection } from '@/components/home/HeroSection';
import { FeaturedProducts } from '@/components/home/FeaturedProducts';
import { CategoriesGrid } from '@/components/home/CategoriesGrid';
import { WhyChooseUs } from '@/components/home/WhyChooseUs';
import { ReviewsSection } from '@/components/home/ReviewsSection';

export default function Home() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen"
    >
      <HeroSection />
      <FeaturedProducts />
      <CategoriesGrid />
      <WhyChooseUs />
      <ReviewsSection />
    </motion.div>
  );
}