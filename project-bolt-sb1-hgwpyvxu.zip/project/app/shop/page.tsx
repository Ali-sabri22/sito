'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, Grid, List, Search, Star, Heart, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCart } from '@/contexts/CartContext';
import Link from 'next/link';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  category: string;
  badge?: string;
  isNew?: boolean;
  inStock: boolean;
}

export default function ShopPage() {
  const [products] = useState<Product[]>([
    {
      id: '1',
      name: 'المنتج الاول',
      price: 2500,
      originalPrice: 3000,
      image: '/sabeel.jpg',
      rating: 4.8,
      reviews: 124,
      category: 'shorts',
      badge: 'خصم 20%',
      inStock: true
    },
    {
      id: '2',
      name: 'المنتج الثاني',
      price: 850,
      originalPrice: 1200,
      image: '/sabeel.jpg',
      rating: 4.6,
      reviews: 89,
      category: 'shorts',
      badge: 'الأكثر مبيعاً',
      inStock: true
    },
    {
      id: '3',
      name: 'المنتج الثالث',
      price: 1200,
      image: '/sabeel.jpg',
      rating: 4.9,
      reviews: 156,
      category: 'shorts',
      badge: 'جديد',
      isNew: true,
      inStock: true
    },
    {
      id: '4',
      name: 'المنتج الرابع',
      price: 450,
      originalPrice: 600,
      image: '/sabeel.jpg',
      rating: 4.7,
      reviews: 92,
      category: 'shorts',
      inStock: true
    },
    {
      id: '5',
      name: 'المنتج الخامس',
      price: 1800,
      image: '/sabeel.jpg',
      rating: 4.8,
      reviews: 203,
      category: 'shorts',
      badge: 'حصري',
      inStock: true
    },
    {
      id: '6',
      name: 'المنتج السادس',
      price: 320,
      image: '/sabeel.jpg',
      rating: 4.5,
      reviews: 78,
      category: 'shorts',
      inStock: false
    },
    {
      id: '7',  
      name: 'المنتج السابع',
      price: 5500,
      originalPrice: 6500,
      image: '/sabeel.jpg',
      rating: 4.9,
      reviews: 67,
      category: 'shorts',
      inStock: true
    },
    {
      id: '8',
      name: 'المنتج الثامن',
      price: 750,
      image: '/sabeel.jpg',
      rating: 4.6,
      reviews: 134,
      category: 'shorts',
      isNew: true,
      inStock: true
    }
  ]);

  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState('all');
  const [sortBy, setSortBy] = useState('featured');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { addItem } = useCart();

  const categories = [
    { id: 'all', name: 'جميع الفئات', count: products.length },
    { id: 'shorts', name: 'شورتات سبيل', count: products.filter(p => p.category === 'shorts').length },
  ];

  const priceRanges = [
    { id: 'all', name: 'جميع الأسعار' },
    { id: '0-500', name: 'أقل من 500 جنيه' },
    { id: '500-1000', name: '500 - 1000 جنيه' },
    { id: '1000-2000', name: '1000 - 2000 جنيه' },
    { id: '2000+', name: 'أكثر من 2000 جنيه' },
  ];

  const sortOptions = [
    { id: 'featured', name: 'المميزة' },
    { id: 'newest', name: 'الأحدث' },
    { id: 'price-low', name: 'السعر: من الأقل للأعلى' },
    { id: 'price-high', name: 'السعر: من الأعلى للأقل' },
    { id: 'rating', name: 'التقييم الأعلى' },
  ];

  useEffect(() => {
    setIsLoading(true);
    
    let filtered = [...products];

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    // Price range filter
    if (priceRange !== 'all') {
      filtered = filtered.filter(product => {
        const price = product.price;
        switch (priceRange) {
          case '0-500':
            return price < 500;
          case '500-1000':
            return price >= 500 && price < 1000;
          case '1000-2000':
            return price >= 1000 && price < 2000;
          case '2000+':
            return price >= 2000;
          default:
            return true;
        }
      });
    }

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        default:
          return 0;
      }
    });

    setTimeout(() => {
      setFilteredProducts(filtered);
      setIsLoading(false);
    }, 500);
  }, [searchQuery, selectedCategory, priceRange, sortBy, products]);

  const handleAddToCart = (product: Product) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-6 sm:py-8">
        {/* Page Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 sm:mb-8"
        >
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-2 sm:mb-4">متجر المنتجات</h1>
          <p className="text-gray-600 text-base sm:text-lg">اكتشف أفضل المنتجات بأسعار منافسة</p>
        </motion.div>

        {/* Search and Filters Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-lg shadow-sm p-4 sm:p-6 mb-6 sm:mb-8"
        >
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 w-full max-w-md">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 sm:w-5 sm:h-5" />
              <Input
                type="text"
                placeholder="ابحث عن المنتجات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 text-base"
              />
            </div>

            {/* Sort and View Controls */}
            <div className="flex items-center gap-3 w-full lg:w-auto">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map(option => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>

              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden"
              >
                <Filter className="w-4 h-4 ml-2" />
                فلاتر
              </Button>
            </div>
          </div>

          {/* Results Count */}
          <div className="mt-4 pt-4 border-t text-sm text-gray-600">
            عرض {filteredProducts.length} منتج من أصل {products.length}
            {searchQuery && ` للبحث "${searchQuery}"`}
          </div>
        </motion.div>

        <div className="flex gap-6 lg:gap-8">
          {/* Sidebar Filters */}
          <motion.aside
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className={`w-full lg:w-80 space-y-6 ${showFilters ? 'block' : 'hidden lg:block'}`}
          >
            {/* Price Range */}
            <div className="bg-white rounded-lg shadow-sm p-4 sm:p-6">
              <h3 className="font-semibold mb-4">نطاق السعر</h3>
              <RadioGroup value={priceRange} onValueChange={setPriceRange}>
                {priceRanges.map(range => (
                  <div key={range.id} className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value={range.id} id={range.id} />
                    <Label htmlFor={range.id} className="cursor-pointer">
                      {range.name}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </motion.aside>

          {/* Products Grid */}
          <div className="flex-1">
            <AnimatePresence mode="wait">
              {isLoading ? (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className={viewMode === 'grid' 
                    ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6'
                    : 'space-y-4'
                  }
                >
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-white rounded-lg shadow-sm p-4 sm:p-6 animate-pulse">
                      <div className="bg-gray-200 aspect-square rounded-lg mb-4" />
                      <div className="h-4 bg-gray-200 rounded mb-2" />
                      <div className="h-4 bg-gray-200 rounded w-2/3 mb-2" />
                      <div className="h-6 bg-gray-200 rounded w-1/3" />
                    </div>
                  ))}
                </motion.div>
              ) : (
                <motion.div
                  key="products"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className={viewMode === 'grid' 
                    ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6'
                    : 'space-y-4'
                  }
                >
                  {filteredProducts.map((product, index) => (
                    <motion.div
                      key={product.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="group hover:shadow-xl transition-all duration-300 overflow-hidden h-full">
                        <div className="relative">
                          <img
                            src={product.image}
                            alt={product.name}
                            className={`w-full object-cover group-hover:scale-105 transition-transform duration-300 ${
                              viewMode === 'grid' ? 'h-48 sm:h-64' : 'h-32'
                            }`}
                          />
                          
                          {/* Badge */}
                          {product.badge && (
                            <Badge 
                              className={`absolute top-3 right-3 text-xs sm:text-sm ${
                                product.badge.includes('خصم') ? 'bg-red-500' :
                                product.badge === 'جديد' ? 'bg-green-500' :
                                'bg-orange-500'
                              }`}
                            >
                              {product.badge}
                            </Badge>
                          )}

                          {/* Stock Status */}
                          {!product.inStock && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                              <span className="bg-white px-3 py-1 sm:px-4 sm:py-2 rounded-lg font-semibold text-gray-900 text-sm">
                                غير متوفر
                              </span>
                            </div>
                          )}

                          {/* Wishlist Button */}
                          <Button
                            variant="outline"
                            size="sm"
                            className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                          >
                            <Heart className="w-3 h-3 sm:w-4 sm:h-4" />
                          </Button>

                          {/* Quick Add Button */}
                          {product.inStock && (
                            <Button
                              size="sm"
                              className="absolute bottom-3 left-1/2 transform -translate-x-1/2 bg-orange-500 hover:bg-orange-600 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 text-xs sm:text-sm"
                              onClick={() => handleAddToCart(product)}
                            >
                              <ShoppingCart className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                              أضف للسلة
                            </Button>
                          )}
                        </div>

                        <CardContent className="p-3 sm:p-4">
                          <Link href={`/product/${product.id}`}>
                            <h3 className="font-semibold text-sm sm:text-lg mb-2 group-hover:text-orange-600 transition-colors cursor-pointer line-clamp-2">
                              {product.name}
                            </h3>
                          </Link>
                          
                          {/* Rating */}
                          <div className="flex items-center gap-1 mb-3">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-3 h-3 sm:w-4 sm:h-4 ${
                                    i < Math.floor(product.rating)
                                      ? 'text-yellow-400 fill-current'
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-xs sm:text-sm text-gray-600">
                              {product.rating} ({product.reviews})
                            </span>
                          </div>

                          {/* Price */}
                          <div className="flex items-center gap-2 mb-4 flex-wrap">
                            <span className="text-lg sm:text-2xl font-bold text-orange-600">
                              {product.price} جنيه
                            </span>
                            {product.originalPrice && (
                              <span className="text-sm sm:text-base text-gray-500 line-through">
                                {product.originalPrice} جنيه
                              </span>
                            )}
                          </div>

                          {/* List View Additional Info */}
                          {viewMode === 'list' && (
                            <div className="flex justify-between items-center">
                              <Badge variant="outline">{categories.find(c => c.id === product.category)?.name}</Badge>
                              {product.inStock && (
                                <Button
                                  size="sm"
                                  onClick={() => handleAddToCart(product)}
                                  className="bg-orange-500 hover:bg-orange-600"
                                >
                                  <ShoppingCart className="w-4 h-4 ml-2" />
                                  أضف للسلة
                                </Button>
                              )}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* No Results */}
            {!isLoading && filteredProducts.length === 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-12 sm:py-16"
              >
                <div className="text-4xl sm:text-6xl mb-4">🔍</div>
                <h3 className="text-xl sm:text-2xl font-semibold mb-2">لا توجد منتجات</h3>
                <p className="text-gray-600 mb-6 text-sm sm:text-base">
                  لم نجد أي منتجات تطابق معايير البحث الخاصة بك
                </p>
                <Button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setPriceRange('all');
                  }}
                  variant="outline"
                >
                  مسح الفلاتر
                </Button>
              </motion.div>
            )}

            {/* Load More / Pagination */}
            {!isLoading && filteredProducts.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mt-8 sm:mt-12"
              >
                <Button variant="outline" size="lg" className="px-6 sm:px-8">
                  تحميل المزيد
                </Button>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}