import './globals.css';
import type { Metadata } from 'next';
import { Inter, Cairo } from 'next/font/google';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Toaster } from '@/components/ui/sonner';
import { CartProvider } from '@/contexts/CartContext';
import { AuthProvider } from '@/contexts/AuthContext';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const cairo = Cairo({ 
  subsets: ['latin', 'arabic'],
  variable: '--font-cairo',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'سبيل - Sabil | شورتات محتشمة للرجال المسلمين',
  description: 'شورتات سبيل - تغطية من السرة للركبة، مثالية للبحر والجيم والحياة اليومية. جودة عالية وتصميم مريح للرجال المسلمين',
  keywords: 'شورتات محتشمة, ملابس رجالية, سبيل, شورت إسلامي, ملابس البحر, ملابس الجيم',
  authors: [{ name: 'Sabil' }],
  icons: {
    icon: '/sabeel.jpg',
    shortcut: '/sabeel.jpg',
    apple: '/sabeel.jpg',
  },
  openGraph: {
    title: 'سبيل - Sabil',
    description: 'شورتات محتشمة للرجال المسلمين - تغطية من السرة للركبة',
    type: 'website',
    locale: 'ar_EG',
    images: ['/sabeel.jpg'],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className={`${inter.variable} ${cairo.variable}`}>
      <head>
        <link rel="icon" href="/sabeel.jpg" />
        <link rel="apple-touch-icon" href="/sabeel.jpg" />
      </head>
      <body className="min-h-screen bg-background font-cairo">
        <AuthProvider>
          <CartProvider>
            <Header />
            <main className="flex-1">
              {children}
            </main>
            <Footer />
            <Toaster />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}