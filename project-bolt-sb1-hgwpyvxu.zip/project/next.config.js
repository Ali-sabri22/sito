// app/product/[id]/page.tsx

import { notFound } from 'next/navigation';

type Product = {
  id: string;
  name: string;
};

// ✅ Finta funzione per recuperare prodotti
async function getProducts(): Promise<Product[]> {
  return [
    { id: '1', name: 'تيشيرت أبيض' },
    { id: '2', name: 'بنطلون جينز' },
    { id: '3', name: 'قبعة صيفية' }
  ];
}

// ✅ Diciamo a Next quali pagine creare (obbligatorio per output: 'export')
export async function generateStaticParams() {
  const products = await getProducts();
  return products.map((product) => ({
    id: product.id
  }));
}

// ✅ Pagina del prodotto
export default async function ProductPage({ params }: { params: { id: string } }) {
  const products = await getProducts();
  const product = products.find((p) => p.id === params.id);

  if (!product) return notFound();

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">المنتج: {product.name}</h1>
      <p className="text-gray-600">معرّف المنتج: {product.id}</p>
    </div>
  );
}
