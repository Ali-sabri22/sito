'use client';

import { motion } from 'framer-motion';
import { useRef } from 'react';
import { ChevronLeft, ChevronRight, Star, Heart, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';

export function FeaturedProducts() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { addItem } = useCart();

  const products = [
    {
      id: '1',
      name: 'المنتج الاول',
      price: 2500,
      originalPrice: 3000,
      image: '/sabeel.jpg',
      rating: 4.8,
      reviews: 124,
      badge: 'خصم 20%'
    },
    {
      id: '2',
      name: 'المنتج الثاني',
      price: 850,
      originalPrice: 1200,
      image: '/sabeel.jpg',
      rating: 4.6,
      reviews: 89,
      badge: 'الأكثر مبيعاً'
    },
    {
      id: '3',
      name: 'المنتج الثالث',
      price: 1200,
      image: '/sabeel.jpg',
      rating: 4.9,
      reviews: 156,
      badge: 'جديد'
    },
    {
      id: '4',
      name: 'المنتج الرابع',
      price: 450,
      originalPrice: 600,
      image: '/sabeel.jpg',
      rating: 4.7,
      reviews: 92,
      badge: 'خصم'
    },
    {
      id: '5',
      name: 'المنتج الخامس',
      price: 1800,
      image: '/sabeel.jpg',
      rating: 4.8,
      reviews: 203,
      badge: 'حصري'
    },
    {
      id: '6',
      name: 'المنتج السادس',
      price: 320,
      image: '/sabeel.jpg',
      rating: 4.5,
      reviews: 78,
    }
  ];

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = window.innerWidth < 768 ? 280 : 320;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    });
  };

  return (
    <section className="py-12 sm:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8 sm:mb-12"
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">الجديد والعروض الحصرية</h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto px-4">
            اكتشف أحدث المنتجات والعروض المميزة المختارة خصيصاً لك
          </p>
        </motion.div>

        {/* Products Carousel */}
        <div className="relative">
          {/* Navigation Buttons - Hidden on mobile */}
          <Button
            variant="outline"
            size="sm"
            className="absolute left-2 sm:left-0 top-1/2 transform -translate-y-1/2 z-10 bg-white shadow-lg hover:bg-gray-50 hidden sm:flex"
            onClick={() => scroll('left')}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className="absolute right-2 sm:right-0 top-1/2 transform -translate-y-1/2 z-10 bg-white shadow-lg hover:bg-gray-50 hidden sm:flex"
            onClick={() => scroll('right')}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>

          {/* Products Grid */}
          <div
            ref={scrollRef}
            className="flex gap-4 sm:gap-6 overflow-x-auto scrollbar-hide pb-4 scroll-smooth px-4 sm:px-12"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex-none w-72 sm:w-80"
              >
                <Card className="group hover:shadow-xl transition-all duration-300 overflow-hidden h-full">
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-48 sm:h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    
                    {/* Badge */}
                    {product.badge && (
                      <Badge className="absolute top-3 right-3 bg-orange-500 text-xs sm:text-sm">
                        {product.badge}
                      </Badge>
                    )}

                    {/* Wishlist Button */}
                    <Button
                      variant="outline"
                      size="sm"
                      className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    >
                      <Heart className="w-4 h-4" />
                    </Button>

                    {/* Quick Add Button */}
                    <Button
                      size="sm"
                      className="absolute bottom-3 left-1/2 transform -translate-x-1/2 bg-orange-500 hover:bg-orange-600 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 text-xs sm:text-sm"
                      onClick={() => handleAddToCart(product)}
                    >
                      <ShoppingCart className="w-4 h-4 ml-2" />
                      أضف للسلة
                    </Button>
                  </div>

                  <CardContent className="p-4">
                    <h3 className="font-semibold text-base sm:text-lg mb-2 group-hover:text-orange-600 transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                    
                    {/* Rating */}
                    <div className="flex items-center gap-1 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 sm:w-4 sm:h-4 ${
                              i < Math.floor(product.rating)
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs sm:text-sm text-gray-600">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>

                    {/* Price */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-lg sm:text-2xl font-bold text-orange-600">
                        {product.price} جنيه
                      </span>
                      {product.originalPrice && (
                        <span className="text-sm sm:text-base text-gray-500 line-through">
                          {product.originalPrice} جنيه
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-6 sm:mt-8"
        >
          <Button variant="outline" size="lg" className="px-6 sm:px-8">
            عرض جميع المنتجات
            <ChevronLeft className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
}