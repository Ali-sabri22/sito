'use client';

import { motion } from 'framer-motion';
import { 
  Shield, 
  Truck, 
  RefreshCw, 
  Headphones, 
  Award, 
  CreditCard 
} from 'lucide-react';

export function WhyChooseUs() {
  const features = [
    {
      icon: Shield,
      title: 'ضمان الجودة',
      description: 'جميع منتجاتنا مضمونة الجودة مع ضمان الاستبدال'
    },
    {
      icon: Truck,
      title: 'شحن مجاني',
      description: 'شحن مجاني لجميع الطلبات أكثر من 500 جنيه'
    },
    {
      icon: RefreshCw,
      title: 'سهولة الإرجاع',
      description: 'إرجاع مجاني خلال 30 يوم من تاريخ الشراء'
    },
    {
      icon: Headphones,
      title: 'دعم على مدار الساعة',
      description: 'فريق خدمة العملاء متاح 24/7 لمساعدتك'
    },
    {
      icon: Award,
      title: 'منتجات أصلية',
      description: '100% منتجات أصلية من موردين معتمدين'
    },
    {
      icon: CreditCard,
      title: 'دفع آمن',
      description: 'معاملات مشفرة وطرق دفع متنوعة وآمنة'
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold mb-4">لماذا تختارنا؟</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            نحن ملتزمون بتقديم أفضل تجربة تسوق مع خدمات متميزة تضمن رضاك التام
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group"
              >
                <div className="bg-white rounded-xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-orange-200">
                  <motion.div
                    className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-6 group-hover:bg-orange-500 transition-all duration-300"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <Icon className="w-8 h-8 text-orange-500 group-hover:text-white transition-colors duration-300" />
                  </motion.div>
                  
                  <h3 className="text-xl font-semibold mb-3 group-hover:text-orange-600 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  
                  <p className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 text-center"
        >
          <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                <div className="text-3xl font-bold text-orange-600 mb-2">1K+</div>
                <div className="text-gray-600">عميل سعيد</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-orange-600 mb-2">20+</div>
                <div className="text-gray-600">منتج متاح</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-orange-600 mb-2">99%</div>
                <div className="text-gray-600">معدل الرضا</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-orange-600 mb-2">24/7</div>
                <div className="text-gray-600">دعم العملاء</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}