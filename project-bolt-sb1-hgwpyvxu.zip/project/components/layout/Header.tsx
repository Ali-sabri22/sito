'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  ShoppingCart, 
  User, 
  Menu, 
  X, 
  Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { CartOverlay } from '@/components/cart/CartOverlay';
import { SearchOverlay } from '@/components/search/SearchOverlay';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { state: cartState, toggleCart } = useCart();
  const { isAuthenticated, user } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when clicking outside or on escape
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (isMobileMenuOpen && !target.closest('.mobile-menu') && !target.closest('.mobile-menu-trigger')) {
        setIsMobileMenuOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsMobileMenuOpen(false);
      }
    };

    if (isMobileMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden'; // Prevent background scroll
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const navItems = [
    { href: '/', label: 'الرئيسية' },
    { href: '/shop', label: 'المتجر' },
    { href: '/about', label: 'من نحن' },
    { href: '/contact', label: 'اتصل بنا' },
  ];

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <motion.header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-border/20' 
            : 'bg-transparent'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3 space-x-reverse z-50 relative">
              <motion.div
                className="flex items-center space-x-2 space-x-reverse"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <img 
                  src="/sabeel.jpg" 
                  alt="سبيل" 
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover"
                />
                <div className={`text-xl sm:text-2xl font-bold transition-colors duration-300 ${
                  isScrolled ? 'text-orange-600' : 'text-white'
                }`}>
                  ًسًــــــــبّـــــــيـــــــّــلَ
                </div>
              </motion.div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8 space-x-reverse">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`transition-colors duration-200 font-medium ${
                    isScrolled 
                      ? 'text-foreground hover:text-orange-600' 
                      : 'text-white hover:text-orange-300'
                  }`}
                >
                  <span>{item.label}</span>
                </Link>
              ))}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center space-x-2 space-x-reverse">
              {/* Search - Hidden on small screens */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsSearchOpen(true)}
                className={`hidden sm:flex transition-colors duration-300 ${
                  isScrolled 
                    ? 'text-foreground hover:bg-accent' 
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <Search className="w-5 h-5" />
              </Button>

              {/* Wishlist - Hidden on small screens */}
              <Button 
                variant="ghost" 
                size="sm" 
                className={`hidden md:flex transition-colors duration-300 ${
                  isScrolled 
                    ? 'text-foreground hover:bg-accent' 
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <Heart className="w-5 h-5" />
              </Button>

              {/* Cart */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleCart}
                className={`relative transition-colors duration-300 ${
                  isScrolled 
                    ? 'text-foreground hover:bg-accent' 
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                {cartState.itemCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs p-0 min-w-[20px]"
                  >
                    {cartState.itemCount}
                  </Badge>
                )}
              </Button>

              {/* User Account - Hidden on mobile */}
              <div className="relative group hidden lg:block">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className={`transition-colors duration-300 ${
                    isScrolled 
                      ? 'text-foreground hover:bg-accent' 
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  <User className="w-5 h-5" />
                </Button>
                
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-border/20 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <div className="py-2">
                    {isAuthenticated ? (
                      <>
                        <div className="px-4 py-2 border-b border-border/20">
                          <p className="text-sm font-medium">{user?.name}</p>
                          <p className="text-xs text-muted-foreground">{user?.email}</p>
                        </div>
                        <Link href="/account" className="block px-4 py-2 text-sm hover:bg-muted">
                          حسابي
                        </Link>
                        <Link href="/orders" className="block px-4 py-2 text-sm hover:bg-muted">
                          طلباتي
                        </Link>
                        <Link href="/wishlist" className="block px-4 py-2 text-sm hover:bg-muted">
                          المفضلة
                        </Link>
                      </>
                    ) : (
                      <>
                        <Link href="/auth/login" className="block px-4 py-2 text-sm hover:bg-muted">
                          تسجيل الدخول
                        </Link>
                        <Link href="/auth/register" className="block px-4 py-2 text-sm hover:bg-muted">
                          إنشاء حساب
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Mobile Menu Toggle */}
              <Button
                variant="ghost"
                size="sm"
                className={`lg:hidden mobile-menu-trigger transition-colors duration-300 ${
                  isScrolled || isMobileMenuOpen
                    ? 'text-foreground hover:bg-accent' 
                    : 'text-white hover:bg-white/10'
                }`}
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/50 z-40 lg:hidden"
              />

              {/* Mobile Menu Panel */}
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="mobile-menu fixed top-0 right-0 h-full w-full max-w-sm bg-white shadow-xl z-50 lg:hidden overflow-y-auto"
              >
                <div className="flex flex-col h-full">
                  {/* Mobile Menu Header */}
                  <div className="flex items-center justify-between p-4 border-b bg-orange-50">
                    <div className="flex items-center space-x-3 space-x-reverse">
                      <img 
                        src="/sabeel.jpg" 
                        alt="سبيل" 
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <h2 className="text-xl font-bold text-orange-600">سبيل</h2>
                    </div>
                    <Button variant="ghost" size="sm" onClick={closeMobileMenu}>
                      <X className="w-5 h-5" />
                    </Button>
                  </div>

                  {/* Mobile Navigation */}
                  <nav className="flex-1 p-4">
                    <div className="space-y-2">
                      {navItems.map((item) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="block py-3 px-4 text-lg font-medium text-gray-900 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-all duration-200"
                          onClick={closeMobileMenu}
                        >
                          {item.label}
                        </Link>
                      ))}
                    </div>

                    {/* Mobile Search */}
                    <div className="mt-6 pt-4 border-t">
                      <Button
                        variant="outline"
                        className="w-full justify-start"
                        onClick={() => {
                          setIsSearchOpen(true);
                          closeMobileMenu();
                        }}
                      >
                        <Search className="w-4 h-4 ml-2" />
                        البحث في المنتجات
                      </Button>
                    </div>

                    {/* Mobile User Section */}
                    <div className="mt-6 pt-4 border-t">
                      {isAuthenticated ? (
                        <div className="space-y-3">
                          <div className="flex items-center space-x-3 space-x-reverse p-3 bg-gray-50 rounded-lg">
                            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-orange-600" />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{user?.name}</p>
                              <p className="text-xs text-gray-500">{user?.email}</p>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <Link
                              href="/account"
                              className="block py-2 px-3 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded transition-all"
                              onClick={closeMobileMenu}
                            >
                              حسابي
                            </Link>
                            <Link
                              href="/orders"
                              className="block py-2 px-3 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded transition-all"
                              onClick={closeMobileMenu}
                            >
                              طلباتي
                            </Link>
                            <Link
                              href="/wishlist"
                              className="block py-2 px-3 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded transition-all"
                              onClick={closeMobileMenu}
                            >
                              المفضلة
                            </Link>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <Link href="/auth/login" onClick={closeMobileMenu}>
                            <Button className="w-full bg-orange-500 hover:bg-orange-600">
                              تسجيل الدخول
                            </Button>
                          </Link>
                          <Link href="/auth/register" onClick={closeMobileMenu}>
                            <Button variant="outline" className="w-full">
                              إنشاء حساب
                            </Button>
                          </Link>
                        </div>
                      )}
                    </div>

                    {/* Mobile Actions */}
                    <div className="mt-6 pt-4 border-t">
                      <div className="grid grid-cols-2 gap-3">
                        <Button
                          variant="outline"
                          className="flex items-center justify-center space-x-2 space-x-reverse"
                          onClick={closeMobileMenu}
                        >
                          <Heart className="w-4 h-4" />
                          <span>المفضلة</span>
                        </Button>
                        <Button
                          variant="outline"
                          className="flex items-center justify-center space-x-2 space-x-reverse relative"
                          onClick={() => {
                            toggleCart();
                            closeMobileMenu();
                          }}
                        >
                          <ShoppingCart className="w-4 h-4" />
                          <span>السلة</span>
                          {cartState.itemCount > 0 && (
                            <Badge 
                              variant="destructive" 
                              className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs p-0"
                            >
                              {cartState.itemCount}
                            </Badge>
                          )}
                        </Button>
                      </div>
                    </div>
                  </nav>

                  {/* Mobile Menu Footer */}
                  <div className="p-4 border-t bg-gray-50">
                    <p className="text-center text-sm text-gray-500">
                      © 2024 سبيل - جميع الحقوق محفوظة
                    </p>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </motion.header>

      {/* Overlays */}
      <CartOverlay />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
}