'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Youtube,
  Mail,
  Phone,
  MapPin,
  CreditCard,
  Shield,
  Truck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function Footer() {
  const footerSections = [
    {
      title: 'روابط سريعة',
      links: [
        { href: '/', label: 'الرئيسية' },
        { href: '/shop', label: 'المتجر' },
        { href: '/about', label: 'من نحن' },
        { href: '/contact', label: 'اتصل بنا' },
        { href: '/faq', label: 'الأسئلة الشائعة' },
      ]
    },
    {
      title: 'خدمة العملاء',
      links: [
        { href: '/shipping', label: 'الشحن والتوصيل' },
        { href: '/returns', label: 'سياسة الإرجاع' },
        { href: '/warranty', label: 'الضمان' },
        { href: '/support', label: 'الدعم الفني' },
        { href: '/track-order', label: 'تتبع الطلب' },
      ]
    },
    {
      title: 'الشركة',
      links: [
        { href: '/about', label: 'من نحن' },
        { href: '/careers', label: 'الوظائف' },
        { href: '/press', label: 'الصحافة' },
        { href: '/investors', label: 'المستثمرون' },
        { href: '/affiliates', label: 'الشراكات' },
      ]
    }
  ];

  const paymentMethods = [
    'فيزا', 'ماستركارد', 'فوري', 'فودافون كاش', 'PayPal'
  ];

  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-gradient">سبيل</h3>
            <p className="text-gray-300 leading-relaxed">
              وجهتك المثالية لأفضل المنتجات المصرية عالية الجودة. نقدم لك تجربة تسوق فريدة مع خدمة عملاء متميزة.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-2">
              <div className="flex items-center space-x-3 space-x-reverse">
                <Phone className="w-4 h-4 text-orange-500" />
                <span className="text-sm">+20 100 123 4567</span>
                <span className="text-sm">+20 100 123 4567</span>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Mail className="w-4 h-4 text-orange-500" />
                <span className="text-sm">info@sabil.eg</span>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <MapPin className="w-4 h-4 text-orange-500" />
                <span className="text-sm">القاهرة، مصر</span>
              </div>
            </div>
          </div>

          {/* Footer Sections */}
          {footerSections.map((section, index) => (
            <div key={section.title} className="space-y-4">
              <h4 className="text-lg font-semibold">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.href}>
                    <Link 
                      href={link.href}
                      className="text-gray-300 hover:text-orange-500 transition-colors duration-200 text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">النشرة الإخبارية</h4>
            <p className="text-gray-300 text-sm">
              اشترك للحصول على أحدث العروض والمنتجات الجديدة
            </p>
            
            <motion.div 
              className="flex space-x-2 space-x-reverse"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Input 
                type="email" 
                placeholder="بريدك الإلكتروني"
                className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-400"
              />
              <Button className="bg-orange-500 hover:bg-orange-600">
                اشتراك
              </Button>
            </motion.div>

            {/* Social Media */}
            <div className="flex space-x-4 space-x-reverse pt-4">
              {[Facebook, Instagram, Twitter, Youtube].map((Icon, index) => (
                <motion.a
                  key={index}
                  href="#"
                  className="p-2 bg-gray-800 rounded-lg hover:bg-orange-500 transition-colors duration-200"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>
        </div>

        {/* Features Bar */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8 border-t border-b border-gray-700">
          <div className="flex items-center space-x-3 space-x-reverse justify-center md:justify-start">
            <Truck className="w-8 h-8 text-orange-500" />
            <div>
              <h5 className="font-semibold">شحن مجاني</h5>
              <p className="text-sm text-gray-300">للطلبات أكثر من 500 جنيه</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 space-x-reverse justify-center md:justify-start">
            <Shield className="w-8 h-8 text-orange-500" />
            <div>
              <h5 className="font-semibold">دفع آمن</h5>
              <p className="text-sm text-gray-300">معاملات محمية 100%</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 space-x-reverse justify-center md:justify-start">
            <CreditCard className="w-8 h-8 text-orange-500" />
            <div>
              <h5 className="font-semibold">طرق دفع متعددة</h5>
              <p className="text-sm text-gray-300">فيزا، فوري، فودافون كاش</p>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-8 space-y-4 md:space-y-0">
          <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm text-gray-300">
            <Link href="/privacy" className="hover:text-orange-500 transition-colors">
              سياسة الخصوصية
            </Link>
            <Link href="/terms" className="hover:text-orange-500 transition-colors">
              شروط الاستخدام
            </Link>
            <Link href="/cookies" className="hover:text-orange-500 transition-colors">
              سياسة الكوكيز
            </Link>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-sm text-gray-300">
              © 2024 سبيل. جميع الحقوق محفوظة
            </p>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="flex flex-wrap justify-center gap-4 pt-6 border-t border-gray-700 mt-6">
          {paymentMethods.map((method) => (
            <div 
              key={method}
              className="px-3 py-1 bg-gray-800 rounded text-xs text-gray-300"
            >
              {method}
            </div>
          ))}
        </div>
      </div>
    </footer>
  );
}