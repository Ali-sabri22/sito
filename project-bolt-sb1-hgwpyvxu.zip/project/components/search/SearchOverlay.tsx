'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, TrendingUp } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const trendingSearches = [
    'إلكترونيات',
    'أزياء رجالية',
    'مستحضرات تجميل',
    'أحذية',
    'ساعات',
    'حقائب'
  ];

  const recentSearches = [
    'هاتف ذكي',
    'لابتوب',
    'سماعات'
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50"
            onClick={onClose}
          />

          {/* Search Panel */}
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed top-0 left-0 right-0 bg-white shadow-xl z-50 max-h-96 overflow-y-auto"
          >
            <div className="container mx-auto px-4 py-6">
              {/* Search Input */}
              <div className="flex items-center space-x-4 space-x-reverse mb-6">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    ref={inputRef}
                    type="text"
                    placeholder="ابحث عن المنتجات..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10 pl-4 py-3 text-lg"
                  />
                </div>
                <Button variant="ghost" onClick={onClose}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Search Results / Suggestions */}
              {searchQuery ? (
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-900">نتائج البحث</h3>
                  {/* Mock search results */}
                  <div className="space-y-2">
                    {[1, 2, 3].map((item) => (
                      <Link
                        key={item}
                        href={`/product/${item}`}
                        className="flex items-center space-x-3 space-x-reverse p-3 hover:bg-gray-50 rounded-lg transition-colors"
                        onClick={onClose}
                      >
                        <img
                          src={`https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1`}
                          alt="منتج"
                          className="w-12 h-12 object-cover rounded"
                        />
                        <div>
                          <h4 className="font-medium">منتج تجريبي {item}</h4>
                          <p className="text-sm text-gray-500">250 جنيه</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-8">
                  {/* Trending Searches */}
                  <div>
                    <div className="flex items-center space-x-2 space-x-reverse mb-4">
                      <TrendingUp className="w-5 h-5 text-orange-500" />
                      <h3 className="font-semibold text-gray-900">البحث الأكثر رواجاً</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {trendingSearches.map((search) => (
                        <button
                          key={search}
                          onClick={() => setSearchQuery(search)}
                          className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-full text-sm transition-colors"
                        >
                          {search}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Recent Searches */}
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-4">البحث الأخير</h3>
                    <div className="space-y-2">
                      {recentSearches.map((search) => (
                        <button
                          key={search}
                          onClick={() => setSearchQuery(search)}
                          className="block w-full text-right px-3 py-2 hover:bg-gray-50 rounded-lg transition-colors text-gray-600"
                        >
                          {search}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}